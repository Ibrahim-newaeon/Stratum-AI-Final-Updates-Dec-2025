<div class="ekit-feed-items-load-more pinterest">
    <a href="#" class="btn">
        <?php esc_html__('Load More', 'elementskit') ?>
    </a>
</div>