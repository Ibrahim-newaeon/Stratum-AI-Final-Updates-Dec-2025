"""
Stratum AI: Trust Gate Evaluator
================================

The Trust Gate is the checkpoint that determines whether automation actions can
proceed. It sits between Stratum's autopilot engine and the platform adapters,
ensuring that no automation runs when data quality is compromised.

Trust Gate Flow
---------------

    [Autopilot Engine]
           │
           │ Proposed Actions
           ▼
    ┌──────────────┐
    │  TRUST GATE  │◄─── Signal Health Score
    └──────────────┘
           │
           │ Decision
           ▼
    ┌──────────────────────────────────────────┐
    │                                          │
    │   HEALTHY (≥70)  ───► Execute Actions    │
    │                                          │
    │   DEGRADED (40-69) ──► Queue for Review  │
    │                                          │
    │   CRITICAL (<40) ───► Block + Alert      │
    │                                          │
    └──────────────────────────────────────────┘

Gate Override System
--------------------

In some cases, operators may need to override the trust gate:

1. **Manual Override**: An authorized user can approve queued actions even when
   signal health is degraded. This requires explicit acknowledgment that the
   decision may be based on unreliable data.

2. **Emergency Pause**: Force all automation to stop regardless of signal health.
   Useful during known platform issues or major site changes.

3. **Confidence Boost**: Temporarily lower thresholds for specific campaigns,
   useful when launching new campaigns that haven't accumulated enough data.

Audit Trail
-----------

All trust gate decisions are logged with full context:
- Signal health score at decision time
- Action that was proposed
- Decision made (approved/queued/blocked)
- Override details if applicable
- Timestamp and responsible user

This audit trail is crucial for understanding automation behavior and debugging
issues after the fact.
"""

import logging
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass, field
import uuid

from stratum.models import (
    SignalHealth,
    AutomationAction,
    Platform
)
from stratum.core.signal_health import SignalHealthCalculator


logger = logging.getLogger("stratum.core.trust_gate")


class GateDecision(str, Enum):
    """Possible decisions from the trust gate."""
    APPROVED = "approved"           # Action can proceed immediately
    QUEUED = "queued"               # Action queued for manual review
    BLOCKED = "blocked"             # Action rejected due to critical state
    OVERRIDDEN = "overridden"       # Action approved via manual override


class OverrideReason(str, Enum):
    """Reasons for overriding the trust gate."""
    MANUAL_APPROVAL = "manual_approval"      # Human approved despite low health
    EMERGENCY_CHANGE = "emergency_change"    # Urgent change needed
    KNOWN_ISSUE = "known_issue"              # Platform issue acknowledged
    TESTING = "testing"                      # Testing/development override


@dataclass
class GateResult:
    """Result of a trust gate evaluation."""
    decision: GateDecision
    signal_health: SignalHealth
    action: AutomationAction
    reason: str
    override: Optional[OverrideReason] = None
    override_by: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    gate_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/storage."""
        return {
            "gate_id": self.gate_id,
            "decision": self.decision.value,
            "signal_health_score": self.signal_health.score,
            "action_type": self.action.action_type,
            "entity_id": self.action.entity_id,
            "reason": self.reason,
            "override": self.override.value if self.override else None,
            "override_by": self.override_by,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class GateConfiguration:
    """Configuration for trust gate behavior."""
    healthy_threshold: float = 70.0
    degraded_threshold: float = 40.0
    
    # Action-specific thresholds (some actions may require higher confidence)
    action_thresholds: Dict[str, float] = field(default_factory=lambda: {
        "update_budget": 70.0,        # Standard threshold
        "update_bid": 75.0,           # Slightly higher for bid changes
        "update_status": 65.0,        # Can tolerate more uncertainty
        "create_campaign": 60.0,      # New campaigns are lower risk
        "create_adset": 60.0,
        "create_ad": 60.0,
    })
    
    # Platform-specific adjustments
    platform_adjustments: Dict[Platform, float] = field(default_factory=lambda: {
        Platform.META: 0.0,           # No adjustment
        Platform.GOOGLE: 0.0,
        Platform.TIKTOK: -5.0,        # Slightly more lenient (newer platform)
        Platform.SNAPCHAT: -5.0,
    })
    
    # Emergency pause flag
    emergency_pause: bool = False
    
    # Require manual approval for all actions (regardless of health)
    require_manual_approval: bool = False


class TrustGate:
    """
    The Trust Gate evaluates whether automation actions should proceed.
    
    This is the central decision point for all automation. Every action
    proposed by the autopilot engine must pass through the trust gate,
    which checks the current signal health and makes a decision.
    
    Usage:
    
        gate = TrustGate()
        
        # Evaluate a single action
        result = gate.evaluate(
            action=budget_update_action,
            signal_health=current_health
        )
        
        if result.decision == GateDecision.APPROVED:
            await adapter.execute_action(action)
        elif result.decision == GateDecision.QUEUED:
            queue_for_review(action, result)
        else:
            log_blocked_action(action, result)
        
        # Batch evaluation
        results = gate.evaluate_batch(actions, signal_health)
    """
    
    def __init__(self, config: Optional[GateConfiguration] = None):
        """
        Initialize the trust gate with optional custom configuration.
        
        If no config is provided, default thresholds are used.
        """
        self.config = config or GateConfiguration()
        self._override_tokens: Dict[str, Tuple[OverrideReason, str, datetime]] = {}
        self._audit_log: List[GateResult] = []
        
        logger.info(
            f"TrustGate initialized with thresholds: "
            f"healthy={self.config.healthy_threshold}, "
            f"degraded={self.config.degraded_threshold}"
        )
    
    def evaluate(
        self,
        action: AutomationAction,
        signal_health: SignalHealth,
        override_token: Optional[str] = None
    ) -> GateResult:
        """
        Evaluate whether an action should proceed through the gate.
        
        This is the core decision function. It considers:
        1. Emergency pause status
        2. Signal health score vs thresholds
        3. Action-specific threshold adjustments
        4. Platform-specific adjustments
        5. Override tokens for manual approval
        
        Args:
            action: The proposed automation action
            signal_health: Current signal health for the account
            override_token: Optional token from manual approval flow
        
        Returns:
            GateResult with decision and full context
        """
        logger.debug(f"Evaluating action {action.action_type} for {action.entity_id}")
        
        # Check emergency pause
        if self.config.emergency_pause:
            result = GateResult(
                decision=GateDecision.BLOCKED,
                signal_health=signal_health,
                action=action,
                reason="Emergency pause is active - all automation blocked"
            )
            self._log_decision(result)
            return result
        
        # Check for override token
        if override_token and override_token in self._override_tokens:
            override_reason, override_by, _ = self._override_tokens[override_token]
            result = GateResult(
                decision=GateDecision.OVERRIDDEN,
                signal_health=signal_health,
                action=action,
                reason=f"Manual override applied: {override_reason.value}",
                override=override_reason,
                override_by=override_by
            )
            # Consume the token
            del self._override_tokens[override_token]
            self._log_decision(result)
            return result
        
        # Check if manual approval is required
        if self.config.require_manual_approval:
            result = GateResult(
                decision=GateDecision.QUEUED,
                signal_health=signal_health,
                action=action,
                reason="Manual approval required for all actions"
            )
            self._log_decision(result)
            return result
        
        # Get the effective threshold for this action
        effective_threshold = self._get_effective_threshold(action)
        
        # Make the decision
        if signal_health.score >= effective_threshold:
            result = GateResult(
                decision=GateDecision.APPROVED,
                signal_health=signal_health,
                action=action,
                reason=f"Signal health ({signal_health.score:.1f}) >= threshold ({effective_threshold:.1f})"
            )
        elif signal_health.score >= self.config.degraded_threshold:
            result = GateResult(
                decision=GateDecision.QUEUED,
                signal_health=signal_health,
                action=action,
                reason=f"Signal health degraded ({signal_health.score:.1f}), action queued for review"
            )
        else:
            result = GateResult(
                decision=GateDecision.BLOCKED,
                signal_health=signal_health,
                action=action,
                reason=f"Signal health critical ({signal_health.score:.1f}), action blocked"
            )
        
        self._log_decision(result)
        return result
    
    def evaluate_batch(
        self,
        actions: List[AutomationAction],
        signal_health: SignalHealth
    ) -> List[GateResult]:
        """
        Evaluate multiple actions in a batch.
        
        This is more efficient when processing many actions, and ensures
        they're all evaluated against the same signal health snapshot.
        
        Args:
            actions: List of proposed actions
            signal_health: Current signal health
        
        Returns:
            List of GateResult objects, one per action
        """
        return [self.evaluate(action, signal_health) for action in actions]
    
    def create_override_token(
        self,
        reason: OverrideReason,
        approved_by: str,
        expires_in_minutes: int = 60
    ) -> str:
        """
        Create an override token for manual approval.
        
        Override tokens allow specific actions to bypass the normal threshold
        checks. They're single-use and expire after a set time.
        
        Args:
            reason: Why the override is being granted
            approved_by: Who approved the override (username/email)
            expires_in_minutes: How long the token is valid
        
        Returns:
            Token string to use with evaluate()
        """
        token = str(uuid.uuid4())
        expires_at = datetime.utcnow()
        self._override_tokens[token] = (reason, approved_by, expires_at)
        
        logger.info(f"Override token created by {approved_by}: {reason.value}")
        
        return token
    
    def set_emergency_pause(self, enabled: bool, reason: str = "") -> None:
        """
        Enable or disable emergency pause mode.
        
        When emergency pause is enabled, ALL automation is blocked regardless
        of signal health. Use this during known platform issues or major changes.
        """
        self.config.emergency_pause = enabled
        status = "ENABLED" if enabled else "DISABLED"
        logger.warning(f"Emergency pause {status}: {reason}")
    
    def update_threshold(
        self,
        action_type: Optional[str] = None,
        new_threshold: Optional[float] = None,
        healthy: Optional[float] = None,
        degraded: Optional[float] = None
    ) -> None:
        """
        Update threshold configuration.
        
        Allows runtime adjustment of thresholds without recreating the gate.
        """
        if action_type and new_threshold is not None:
            self.config.action_thresholds[action_type] = new_threshold
            logger.info(f"Updated threshold for {action_type}: {new_threshold}")
        
        if healthy is not None:
            self.config.healthy_threshold = healthy
            logger.info(f"Updated healthy threshold: {healthy}")
        
        if degraded is not None:
            self.config.degraded_threshold = degraded
            logger.info(f"Updated degraded threshold: {degraded}")
    
    def get_audit_log(
        self,
        limit: int = 100,
        action_type: Optional[str] = None,
        decision: Optional[GateDecision] = None
    ) -> List[Dict[str, Any]]:
        """
        Retrieve recent audit log entries.
        
        The audit log contains all trust gate decisions for debugging
        and compliance purposes.
        """
        filtered = self._audit_log
        
        if action_type:
            filtered = [r for r in filtered if r.action.action_type == action_type]
        
        if decision:
            filtered = [r for r in filtered if r.decision == decision]
        
        # Return most recent first
        filtered = list(reversed(filtered))[:limit]
        
        return [r.to_dict() for r in filtered]
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about trust gate decisions.
        
        Useful for monitoring and dashboards.
        """
        if not self._audit_log:
            return {
                "total_evaluations": 0,
                "approved": 0,
                "queued": 0,
                "blocked": 0,
                "overridden": 0,
                "approval_rate": 0.0
            }
        
        total = len(self._audit_log)
        approved = sum(1 for r in self._audit_log if r.decision == GateDecision.APPROVED)
        queued = sum(1 for r in self._audit_log if r.decision == GateDecision.QUEUED)
        blocked = sum(1 for r in self._audit_log if r.decision == GateDecision.BLOCKED)
        overridden = sum(1 for r in self._audit_log if r.decision == GateDecision.OVERRIDDEN)
        
        return {
            "total_evaluations": total,
            "approved": approved,
            "queued": queued,
            "blocked": blocked,
            "overridden": overridden,
            "approval_rate": (approved + overridden) / total if total > 0 else 0.0,
            "average_signal_health": sum(r.signal_health.score for r in self._audit_log) / total
        }
    
    def _get_effective_threshold(self, action: AutomationAction) -> float:
        """
        Calculate the effective threshold for a specific action.
        
        This considers:
        1. Base threshold for the action type
        2. Platform-specific adjustments
        """
        # Start with action-specific threshold or default healthy threshold
        base = self.config.action_thresholds.get(
            action.action_type,
            self.config.healthy_threshold
        )
        
        # Apply platform adjustment
        platform_adj = self.config.platform_adjustments.get(action.platform, 0.0)
        
        return base + platform_adj
    
    def _log_decision(self, result: GateResult) -> None:
        """Log a gate decision to the audit trail."""
        self._audit_log.append(result)
        
        # Keep audit log bounded (last 10000 decisions)
        if len(self._audit_log) > 10000:
            self._audit_log = self._audit_log[-10000:]
        
        # Log to standard logger based on decision
        if result.decision == GateDecision.BLOCKED:
            logger.warning(
                f"GATE BLOCKED: {result.action.action_type} on {result.action.entity_id} - "
                f"{result.reason}"
            )
        elif result.decision == GateDecision.QUEUED:
            logger.info(
                f"GATE QUEUED: {result.action.action_type} on {result.action.entity_id} - "
                f"{result.reason}"
            )
        else:
            logger.debug(
                f"GATE {result.decision.value.upper()}: "
                f"{result.action.action_type} on {result.action.entity_id}"
            )


class TrustGatedAutopilot:
    """
    Convenience wrapper that combines signal health calculation with trust gate.
    
    This class provides a simple interface for evaluating actions with automatic
    signal health calculation, useful when you want the full pipeline in one call.
    
    Usage:
    
        autopilot = TrustGatedAutopilot()
        
        # Evaluate action with automatic health calculation
        can_proceed, result = await autopilot.can_execute(
            action=action,
            emq_scores=emq_scores,
            recent_metrics=metrics
        )
        
        if can_proceed:
            await adapter.execute_action(action)
    """
    
    def __init__(
        self,
        health_calculator: Optional[SignalHealthCalculator] = None,
        trust_gate: Optional[TrustGate] = None
    ):
        """Initialize with optional custom calculator and gate."""
        self.health_calculator = health_calculator or SignalHealthCalculator()
        self.trust_gate = trust_gate or TrustGate()
    
    async def can_execute(
        self,
        action: AutomationAction,
        emq_scores: List,
        recent_metrics: List,
        override_token: Optional[str] = None
    ) -> Tuple[bool, GateResult]:
        """
        Check if an action can be executed based on current signal health.
        
        This method:
        1. Calculates current signal health
        2. Passes action through trust gate
        3. Returns decision
        
        Returns:
            Tuple of (can_proceed: bool, result: GateResult)
        """
        # Calculate signal health
        signal_health = self.health_calculator.calculate(
            platform=action.platform,
            account_id=action.account_id,
            emq_scores=emq_scores,
            recent_metrics=recent_metrics
        )
        
        # Evaluate through trust gate
        result = self.trust_gate.evaluate(
            action=action,
            signal_health=signal_health,
            override_token=override_token
        )
        
        can_proceed = result.decision in [GateDecision.APPROVED, GateDecision.OVERRIDDEN]
        
        return can_proceed, result
