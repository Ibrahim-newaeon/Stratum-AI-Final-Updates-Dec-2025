"""
Stratum AI: Core Components
===========================

Signal Health Calculator and Trust Gate - the brain of Stratum's
trust-gated automation system.
"""

from stratum.core.signal_health import (
    SignalHealthCalculator,
    HEALTHY_THRESHOLD,
    DEGRADED_THRESHOLD,
    quick_health_check,
)
from stratum.core.trust_gate import (
    TrustGate,
    TrustGatedAutopilot,
    GateDecision,
    GateResult,
    GateConfiguration,
    OverrideReason,
)

__all__ = [
    "SignalHealthCalculator",
    "HEALTHY_THRESHOLD",
    "DEGRADED_THRESHOLD",
    "quick_health_check",
    "TrustGate",
    "TrustGatedAutopilot",
    "GateDecision",
    "GateResult",
    "GateConfiguration",
    "OverrideReason",
]
