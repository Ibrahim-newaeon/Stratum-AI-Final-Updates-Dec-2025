"""
Stratum AI: Signal Health Calculator
====================================

This module implements Stratum's core signal health scoring system, which determines
whether automation can safely run for a given account. The signal health score is
a composite metric that evaluates data reliability from multiple angles.

The Philosophy of Trust-Gated Automation
----------------------------------------

Traditional marketing automation tools blindly execute rules regardless of data quality.
If your pixel breaks, your CPA data becomes unreliable, and your automation might
make terrible decisions based on garbage data. Stratum takes a different approach:
we continuously evaluate the trustworthiness of your advertising data, and only
allow automation to run when we're confident the data is reliable.

Think of it like a pilot's pre-flight checklist. You don't take off until all systems
are verified. Similarly, Stratum's autopilot won't adjust your budgets until the
signal health checks pass.

Signal Health Components
------------------------

The overall signal health score (0-100) is calculated from four components:

1. **EMQ Score (25% weight)**: Event Match Quality measures how well your conversion
   data matches the platform's user profiles. Higher match rates mean better attribution
   and more reliable ROAS/CPA numbers.

2. **Data Freshness (25% weight)**: How recently has data been updated? Stale data
   might indicate tracking issues. We check that conversions and spend data are
   flowing as expected.

3. **Variance Stability (25% weight)**: Are metrics behaving consistently? Sudden
   spikes or drops in conversion rates might indicate data issues rather than
   real performance changes.

4. **Anomaly Detection (25% weight)**: Statistical checks for outliers that might
   indicate tracking problems, bot traffic, or other data quality issues.

Trust Gate Thresholds
---------------------

- **HEALTHY (≥70)**: All systems go. Autopilot can run freely. This means all
  four components are scoring reasonably well.

- **DEGRADED (40-69)**: Caution. Autopilot is paused, alerts are sent. Something
  might be wrong with your tracking. Manual review recommended.

- **CRITICAL (<40)**: Stop. All automation blocked. Significant data quality
  issues detected. Do not make decisions based on this data.
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import statistics
from dataclasses import dataclass

from stratum.models import (
    Platform,
    SignalHealth,
    EMQScore,
    PerformanceMetrics,
    UnifiedCampaign
)


logger = logging.getLogger("stratum.core.signal_health")


# Thresholds for trust gate decisions
HEALTHY_THRESHOLD = 70
DEGRADED_THRESHOLD = 40

# EMQ thresholds by event type (on 0-10 scale, converted to 0-100 internally)
EMQ_THRESHOLDS = {
    "Purchase": 8.5,      # Critical for ROAS optimization
    "purchase": 8.5,
    "AddToCart": 6.0,     # Important for upper funnel
    "add_to_cart": 6.0,
    "ViewContent": 4.0,   # Less critical
    "view_content": 4.0,
    "Lead": 7.0,          # Important for lead gen
    "lead": 7.0,
    "default": 5.0        # Default for other events
}

# Component weights for overall score
WEIGHTS = {
    "emq": 0.25,
    "freshness": 0.25,
    "variance": 0.25,
    "anomaly": 0.25
}


@dataclass
class FreshnessCheck:
    """Result of data freshness evaluation."""
    score: float
    last_conversion_time: Optional[datetime]
    last_spend_time: Optional[datetime]
    hours_since_conversion: Optional[float]
    hours_since_spend: Optional[float]
    issues: List[str]


@dataclass
class VarianceCheck:
    """Result of variance stability evaluation."""
    score: float
    conversion_cv: Optional[float]  # Coefficient of variation
    spend_cv: Optional[float]
    cpa_cv: Optional[float]
    issues: List[str]


@dataclass
class AnomalyCheck:
    """Result of anomaly detection."""
    score: float
    anomalies_detected: int
    anomaly_details: List[str]
    issues: List[str]


class SignalHealthCalculator:
    """
    Calculates signal health scores for advertising accounts.
    
    This class is the brain of Stratum's trust-gated system. It takes raw data
    from advertising platforms and computes a reliability score that determines
    whether automation should proceed.
    
    Usage:
    
        calculator = SignalHealthCalculator()
        
        # Calculate signal health for an account
        signal_health = calculator.calculate(
            platform=Platform.META,
            account_id="act_123456",
            emq_scores=emq_scores,
            recent_metrics=metrics_history,
            campaigns=campaigns
        )
        
        if signal_health.autopilot_allowed:
            # Safe to run automation
            pass
        else:
            # Send alerts, pause automation
            handle_degraded_state(signal_health)
    """
    
    def __init__(
        self,
        emq_weight: float = WEIGHTS["emq"],
        freshness_weight: float = WEIGHTS["freshness"],
        variance_weight: float = WEIGHTS["variance"],
        anomaly_weight: float = WEIGHTS["anomaly"]
    ):
        """
        Initialize the calculator with custom weights if needed.
        
        The default weights give equal importance to all four components.
        You might adjust these based on your specific needs. For example,
        if EMQ is particularly critical for your optimization strategy,
        you could increase its weight.
        """
        # Normalize weights to ensure they sum to 1
        total = emq_weight + freshness_weight + variance_weight + anomaly_weight
        self.emq_weight = emq_weight / total
        self.freshness_weight = freshness_weight / total
        self.variance_weight = variance_weight / total
        self.anomaly_weight = anomaly_weight / total
        
        logger.info(
            f"SignalHealthCalculator initialized with weights: "
            f"EMQ={self.emq_weight:.2f}, Freshness={self.freshness_weight:.2f}, "
            f"Variance={self.variance_weight:.2f}, Anomaly={self.anomaly_weight:.2f}"
        )
    
    def calculate(
        self,
        platform: Platform,
        account_id: str,
        emq_scores: List[EMQScore],
        recent_metrics: List[PerformanceMetrics],
        campaigns: Optional[List[UnifiedCampaign]] = None
    ) -> SignalHealth:
        """
        Calculate the overall signal health score for an account.
        
        This is the main entry point for signal health calculation. It
        evaluates all four components and produces a composite score
        along with diagnostic information.
        
        Args:
            platform: Which advertising platform this is for
            account_id: The account being evaluated
            emq_scores: List of EMQ scores for different conversion events
            recent_metrics: Historical performance metrics (ideally 7-30 days)
            campaigns: Optional list of campaigns for additional context
        
        Returns:
            SignalHealth object with overall score and component breakdowns
        """
        logger.info(f"Calculating signal health for {platform.value} account {account_id}")
        
        issues = []
        recommendations = []
        
        # Calculate each component
        emq_result = self._calculate_emq_score(emq_scores)
        freshness_result = self._calculate_freshness_score(recent_metrics)
        variance_result = self._calculate_variance_score(recent_metrics)
        anomaly_result = self._calculate_anomaly_score(recent_metrics)
        
        # Collect issues from all components
        issues.extend(freshness_result.issues)
        issues.extend(variance_result.issues)
        issues.extend(anomaly_result.issues)
        
        # Calculate weighted overall score
        overall_score = (
            emq_result * self.emq_weight +
            freshness_result.score * self.freshness_weight +
            variance_result.score * self.variance_weight +
            anomaly_result.score * self.anomaly_weight
        )
        
        # Generate recommendations based on component scores
        recommendations.extend(
            self._generate_recommendations(
                emq_result,
                freshness_result,
                variance_result,
                anomaly_result
            )
        )
        
        # Create the SignalHealth object
        signal_health = SignalHealth(
            platform=platform,
            account_id=account_id,
            score=round(overall_score, 2),
            emq_score=round(emq_result, 2),
            freshness_score=round(freshness_result.score, 2),
            variance_score=round(variance_result.score, 2),
            anomaly_score=round(anomaly_result.score, 2),
            issues=issues,
            recommendations=recommendations,
            last_calculated=datetime.utcnow()
        )
        
        # Evaluate trust gates
        signal_health.evaluate_gates()
        
        logger.info(
            f"Signal health calculated: {signal_health.score}/100 "
            f"(EMQ: {signal_health.emq_score}, Fresh: {signal_health.freshness_score}, "
            f"Var: {signal_health.variance_score}, Anom: {signal_health.anomaly_score})"
        )
        
        return signal_health
    
    def _calculate_emq_score(self, emq_scores: List[EMQScore]) -> float:
        """
        Calculate the EMQ component score.
        
        EMQ scores from platforms are typically on a 0-10 scale. We convert
        to 0-100 and apply event-specific thresholds. The score reflects
        how well conversion data matches user profiles.
        
        Logic:
        - Find the primary conversion event (usually Purchase)
        - Compare its EMQ to the threshold for that event type
        - Score = (actual_emq / threshold) * 100, capped at 100
        """
        if not emq_scores:
            logger.warning("No EMQ scores provided, defaulting to 50")
            return 50.0  # Neutral score when no data available
        
        # Weight different events by importance
        # Purchase events are most critical for e-commerce optimization
        event_weights = {
            "Purchase": 3.0,
            "purchase": 3.0,
            "AddToCart": 2.0,
            "add_to_cart": 2.0,
            "Lead": 2.5,
            "lead": 2.5,
            "ViewContent": 1.0,
            "view_content": 1.0,
        }
        
        weighted_sum = 0.0
        total_weight = 0.0
        
        for emq in emq_scores:
            threshold = EMQ_THRESHOLDS.get(emq.event_name, EMQ_THRESHOLDS["default"])
            weight = event_weights.get(emq.event_name, 1.0)
            
            # Calculate how well this event meets its threshold
            # Score of 100 means at or above threshold
            ratio = emq.score / threshold if threshold > 0 else 1.0
            component_score = min(ratio * 100, 100)  # Cap at 100
            
            weighted_sum += component_score * weight
            total_weight += weight
        
        if total_weight == 0:
            return 50.0
        
        return weighted_sum / total_weight
    
    def _calculate_freshness_score(
        self,
        metrics: List[PerformanceMetrics]
    ) -> FreshnessCheck:
        """
        Calculate the data freshness component score.
        
        Fresh data is crucial for real-time optimization. If conversions or
        spend data is stale, we can't trust that our automation decisions
        are based on current reality.
        
        Logic:
        - Check when the most recent data was recorded
        - Penalize scores based on hours since last update
        - Full marks for data < 4 hours old
        - Warning at 12+ hours
        - Critical at 24+ hours
        """
        issues = []
        
        if not metrics:
            return FreshnessCheck(
                score=30.0,  # Low score for no data
                last_conversion_time=None,
                last_spend_time=None,
                hours_since_conversion=None,
                hours_since_spend=None,
                issues=["No recent metrics data available"]
            )
        
        # Find the most recent metrics
        now = datetime.utcnow()
        latest_with_conversions = None
        latest_with_spend = None
        
        for m in metrics:
            if m.date_end:
                if m.conversions and m.conversions > 0:
                    if not latest_with_conversions or m.date_end > latest_with_conversions:
                        latest_with_conversions = m.date_end
                if m.spend and m.spend > 0:
                    if not latest_with_spend or m.date_end > latest_with_spend:
                        latest_with_spend = m.date_end
        
        # Calculate hours since last data
        hours_since_conversion = None
        hours_since_spend = None
        
        if latest_with_conversions:
            hours_since_conversion = (now - latest_with_conversions).total_seconds() / 3600
        if latest_with_spend:
            hours_since_spend = (now - latest_with_spend).total_seconds() / 3600
        
        # Score based on freshness
        # Using the worse of the two (conversions vs spend)
        scores = []
        
        if hours_since_conversion is not None:
            if hours_since_conversion < 4:
                scores.append(100)
            elif hours_since_conversion < 12:
                scores.append(80)
            elif hours_since_conversion < 24:
                scores.append(60)
                issues.append(f"Conversion data is {hours_since_conversion:.1f} hours old")
            elif hours_since_conversion < 48:
                scores.append(40)
                issues.append(f"Conversion data is stale ({hours_since_conversion:.1f} hours)")
            else:
                scores.append(20)
                issues.append(f"Conversion data critically stale ({hours_since_conversion:.1f} hours)")
        else:
            scores.append(30)
            issues.append("No recent conversion data found")
        
        if hours_since_spend is not None:
            if hours_since_spend < 4:
                scores.append(100)
            elif hours_since_spend < 12:
                scores.append(85)
            elif hours_since_spend < 24:
                scores.append(70)
            else:
                scores.append(50)
                issues.append(f"Spend data is {hours_since_spend:.1f} hours old")
        else:
            scores.append(40)
            issues.append("No recent spend data found")
        
        final_score = min(scores) if scores else 30
        
        return FreshnessCheck(
            score=final_score,
            last_conversion_time=latest_with_conversions,
            last_spend_time=latest_with_spend,
            hours_since_conversion=hours_since_conversion,
            hours_since_spend=hours_since_spend,
            issues=issues
        )
    
    def _calculate_variance_score(
        self,
        metrics: List[PerformanceMetrics]
    ) -> VarianceCheck:
        """
        Calculate the variance stability component score.
        
        Stable metrics indicate reliable data. High variance might indicate
        tracking issues, bot traffic, or other problems. We use coefficient
        of variation (CV = std_dev / mean) to normalize for scale.
        
        Logic:
        - Calculate CV for key metrics (conversions, spend, CPA)
        - Lower CV = more stable = higher score
        - CV < 0.3 is excellent
        - CV > 1.0 indicates high instability
        """
        issues = []
        
        if len(metrics) < 3:
            return VarianceCheck(
                score=60.0,  # Neutral when insufficient data
                conversion_cv=None,
                spend_cv=None,
                cpa_cv=None,
                issues=["Insufficient data for variance analysis (need 3+ periods)"]
            )
        
        # Extract time series
        conversions = [m.conversions for m in metrics if m.conversions is not None]
        spends = [m.spend for m in metrics if m.spend is not None and m.spend > 0]
        cpas = [m.cpa for m in metrics if m.cpa is not None and m.cpa > 0]
        
        def calculate_cv(values: List[float]) -> Optional[float]:
            """Calculate coefficient of variation."""
            if len(values) < 2:
                return None
            mean = statistics.mean(values)
            if mean == 0:
                return None
            std_dev = statistics.stdev(values)
            return std_dev / mean
        
        conversion_cv = calculate_cv([float(c) for c in conversions]) if conversions else None
        spend_cv = calculate_cv(spends) if spends else None
        cpa_cv = calculate_cv(cpas) if cpas else None
        
        # Score each CV
        def cv_to_score(cv: Optional[float], metric_name: str) -> float:
            if cv is None:
                return 60  # Neutral
            if cv < 0.2:
                return 100  # Very stable
            elif cv < 0.3:
                return 90
            elif cv < 0.5:
                return 75
            elif cv < 0.7:
                return 60
            elif cv < 1.0:
                issues.append(f"High variance in {metric_name} (CV={cv:.2f})")
                return 45
            else:
                issues.append(f"Very high variance in {metric_name} (CV={cv:.2f})")
                return 25
        
        conversion_score = cv_to_score(conversion_cv, "conversions")
        spend_score = cv_to_score(spend_cv, "spend")
        cpa_score = cv_to_score(cpa_cv, "CPA")
        
        # Weight CPA most heavily since it's what we typically optimize
        final_score = (conversion_score * 0.3 + spend_score * 0.3 + cpa_score * 0.4)
        
        return VarianceCheck(
            score=final_score,
            conversion_cv=conversion_cv,
            spend_cv=spend_cv,
            cpa_cv=cpa_cv,
            issues=issues
        )
    
    def _calculate_anomaly_score(
        self,
        metrics: List[PerformanceMetrics]
    ) -> AnomalyCheck:
        """
        Calculate the anomaly detection component score.
        
        Anomalies might indicate tracking issues, bot traffic, or other
        data quality problems. We use simple statistical methods to detect
        outliers in key metrics.
        
        Logic:
        - Calculate z-scores for each metric value
        - Flag values > 3 standard deviations from mean
        - More anomalies = lower score
        """
        issues = []
        anomaly_details = []
        
        if len(metrics) < 5:
            return AnomalyCheck(
                score=70.0,  # Slightly positive when insufficient data
                anomalies_detected=0,
                anomaly_details=[],
                issues=["Insufficient data for anomaly detection (need 5+ periods)"]
            )
        
        def detect_anomalies(values: List[float], metric_name: str) -> int:
            """Detect anomalies using z-score method."""
            if len(values) < 3:
                return 0
            
            mean = statistics.mean(values)
            std_dev = statistics.stdev(values) if len(values) > 1 else 0
            
            if std_dev == 0:
                return 0
            
            anomaly_count = 0
            for i, v in enumerate(values):
                z_score = abs(v - mean) / std_dev
                if z_score > 3:
                    anomaly_count += 1
                    anomaly_details.append(
                        f"{metric_name} anomaly at index {i}: value={v:.2f}, z-score={z_score:.2f}"
                    )
            
            return anomaly_count
        
        total_anomalies = 0
        
        # Check conversions
        conversions = [float(m.conversions) for m in metrics if m.conversions is not None]
        total_anomalies += detect_anomalies(conversions, "conversions")
        
        # Check spend
        spends = [m.spend for m in metrics if m.spend is not None]
        total_anomalies += detect_anomalies(spends, "spend")
        
        # Check CTR
        ctrs = [m.ctr for m in metrics if m.ctr is not None]
        total_anomalies += detect_anomalies(ctrs, "CTR")
        
        # Check CPA
        cpas = [m.cpa for m in metrics if m.cpa is not None and m.cpa > 0]
        total_anomalies += detect_anomalies(cpas, "CPA")
        
        # Score based on anomaly count
        if total_anomalies == 0:
            score = 100
        elif total_anomalies == 1:
            score = 85
        elif total_anomalies == 2:
            score = 70
            issues.append(f"Detected {total_anomalies} anomalies in metrics")
        elif total_anomalies <= 4:
            score = 50
            issues.append(f"Multiple anomalies detected ({total_anomalies})")
        else:
            score = 25
            issues.append(f"High number of anomalies ({total_anomalies}) - data quality concern")
        
        return AnomalyCheck(
            score=score,
            anomalies_detected=total_anomalies,
            anomaly_details=anomaly_details,
            issues=issues
        )
    
    def _generate_recommendations(
        self,
        emq_score: float,
        freshness: FreshnessCheck,
        variance: VarianceCheck,
        anomaly: AnomalyCheck
    ) -> List[str]:
        """
        Generate actionable recommendations based on component scores.
        
        These recommendations help users understand what they need to fix
        to improve their signal health score.
        """
        recommendations = []
        
        # EMQ recommendations
        if emq_score < 60:
            recommendations.append(
                "EMQ is low. Consider implementing Conversions API (CAPI) for server-side tracking, "
                "and ensure you're passing email/phone parameters with conversion events."
            )
        elif emq_score < 80:
            recommendations.append(
                "EMQ could be improved. Check that all user data parameters are being "
                "passed correctly and properly hashed."
            )
        
        # Freshness recommendations
        if freshness.score < 60:
            recommendations.append(
                "Data freshness is concerning. Check that your pixel/tracking is firing correctly "
                "and that there are no delays in data processing."
            )
        
        # Variance recommendations
        if variance.score < 60:
            recommendations.append(
                "Metric variance is high. This might indicate inconsistent tracking, "
                "bot traffic, or significant changes in campaign performance. "
                "Review recent changes and check for tracking issues."
            )
        
        # Anomaly recommendations
        if anomaly.score < 60:
            recommendations.append(
                f"Detected {anomaly.anomalies_detected} statistical anomalies. "
                "Review the affected time periods for tracking issues, "
                "unusual traffic patterns, or external factors."
            )
        
        return recommendations


# Convenience function for quick checks
def quick_health_check(
    emq_scores: List[EMQScore],
    recent_metrics: List[PerformanceMetrics]
) -> Tuple[float, bool]:
    """
    Perform a quick signal health check and return score and autopilot status.
    
    This is a convenience function for simple use cases where you just need
    to know if automation should proceed.
    
    Returns:
        Tuple of (score, autopilot_allowed)
    """
    calculator = SignalHealthCalculator()
    health = calculator.calculate(
        platform=Platform.META,  # Platform doesn't affect calculation
        account_id="quick_check",
        emq_scores=emq_scores,
        recent_metrics=recent_metrics
    )
    return health.score, health.autopilot_allowed
