"""
Stratum AI: Unified Data Models
==============================

These Pydantic models provide a platform-agnostic representation of advertising
entities, allowing Stratum's core logic to work with campaigns, ad sets, and 
performance metrics without caring which platform originated the data.

The key insight here is that all four platforms share similar hierarchies:
- Account → Campaign → Ad Group (Ad Set) → Ad
- Each entity has common attributes: name, status, budget, performance metrics

By normalizing to these unified models, we can:
1. Calculate signal health identically across platforms
2. Apply the same trust gate logic everywhere
3. Execute automation rules without platform-specific branching
"""

from datetime import datetime
from enum import Enum
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field


# ============================================================================
# ENUMS: Standardized status values across all platforms
# ============================================================================

class Platform(str, Enum):
    """
    Identifies which advertising platform originated the data.
    This is crucial for routing updates back to the correct API.
    """
    META = "meta"
    GOOGLE = "google"
    TIKTOK = "tiktok"
    SNAPCHAT = "snapchat"


class EntityStatus(str, Enum):
    """
    Unified status values that map to each platform's native statuses.
    
    Platform Mappings:
    - META: ACTIVE, PAUSED, DELETED, ARCHIVED
    - GOOGLE: ENABLED, PAUSED, REMOVED
    - TIKTOK: ENABLE, DISABLE, DELETE
    - SNAPCHAT: ACTIVE, PAUSED
    """
    ACTIVE = "active"
    PAUSED = "paused"
    DELETED = "deleted"
    PENDING_REVIEW = "pending_review"
    REJECTED = "rejected"
    ARCHIVED = "archived"


class BiddingStrategy(str, Enum):
    """
    Unified bidding strategies across platforms.
    
    Not all platforms support all strategies. The adapter layer
    handles mapping to the closest available option.
    """
    LOWEST_COST = "lowest_cost"          # Meta: LOWEST_COST_WITHOUT_CAP
    COST_CAP = "cost_cap"                # Meta: COST_CAP
    BID_CAP = "bid_cap"                  # Meta: BID_CAP
    TARGET_CPA = "target_cpa"            # Google: TARGET_CPA
    TARGET_ROAS = "target_roas"          # Google: TARGET_ROAS
    MAXIMIZE_CONVERSIONS = "max_conv"    # Google: MAXIMIZE_CONVERSIONS
    MAXIMIZE_VALUE = "max_value"         # Google: MAXIMIZE_CONVERSION_VALUE
    MANUAL_CPC = "manual_cpc"            # All platforms


class OptimizationGoal(str, Enum):
    """
    What the campaign is optimizing for.
    Maps to conversion events across platforms.
    """
    PURCHASES = "purchases"
    ADD_TO_CART = "add_to_cart"
    LEADS = "leads"
    LINK_CLICKS = "link_clicks"
    IMPRESSIONS = "impressions"
    VIDEO_VIEWS = "video_views"
    APP_INSTALLS = "app_installs"


# ============================================================================
# PERFORMANCE METRICS: Unified KPI representation
# ============================================================================

class PerformanceMetrics(BaseModel):
    """
    Standardized performance metrics collected from all platforms.
    
    These metrics feed into Stratum's signal health calculation.
    Fields use Optional because not all platforms report all metrics
    at all times (e.g., ROAS requires conversion value tracking).
    """
    # Core engagement metrics (always available)
    impressions: int = 0
    clicks: int = 0
    spend: float = 0.0
    
    # Computed efficiency metrics
    ctr: Optional[float] = None              # Click-through rate (%)
    cpc: Optional[float] = None              # Cost per click
    cpm: Optional[float] = None              # Cost per 1000 impressions
    
    # Conversion metrics (requires pixel/CAPI setup)
    conversions: Optional[int] = None
    conversion_value: Optional[float] = None
    cpa: Optional[float] = None              # Cost per acquisition
    roas: Optional[float] = None             # Return on ad spend
    
    # Attribution-specific (platform-dependent)
    view_through_conversions: Optional[int] = None
    click_through_conversions: Optional[int] = None
    
    # Video metrics (when applicable)
    video_views: Optional[int] = None
    video_p25: Optional[int] = None          # 25% watched
    video_p50: Optional[int] = None          # 50% watched
    video_p75: Optional[int] = None          # 75% watched
    video_p100: Optional[int] = None         # 100% watched
    
    # Time period for these metrics
    date_start: Optional[datetime] = None
    date_end: Optional[datetime] = None
    
    def compute_derived_metrics(self) -> None:
        """
        Calculate derived metrics from raw data.
        Call this after populating raw fields.
        """
        if self.impressions > 0:
            self.ctr = (self.clicks / self.impressions) * 100
            self.cpm = (self.spend / self.impressions) * 1000
        
        if self.clicks > 0:
            self.cpc = self.spend / self.clicks
        
        if self.conversions and self.conversions > 0:
            self.cpa = self.spend / self.conversions
            
            if self.conversion_value and self.spend > 0:
                self.roas = self.conversion_value / self.spend


# ============================================================================
# SIGNAL HEALTH: EMQ and data quality metrics
# ============================================================================

class EMQScore(BaseModel):
    """
    Event Match Quality score from each platform.
    
    EMQ measures how well your conversion data matches platform user profiles.
    Higher scores mean better attribution and optimization.
    
    Target Scores by Event Type:
    - Purchase: ≥ 8.5/10
    - Add to Cart: ≥ 6.0/10
    - View Content: ≥ 4.0/10
    """
    platform: Platform
    event_name: str                          # e.g., "Purchase", "AddToCart"
    score: float = Field(ge=0, le=10)        # 0-10 scale
    match_rate: Optional[float] = None       # Percentage of matched events
    
    # Breakdown of matching parameters
    email_match_rate: Optional[float] = None
    phone_match_rate: Optional[float] = None
    ip_match_rate: Optional[float] = None
    user_agent_match_rate: Optional[float] = None
    
    last_updated: datetime = Field(default_factory=datetime.utcnow)


class SignalHealth(BaseModel):
    """
    Composite signal health score for trust gate evaluation.
    
    This is the core metric that determines whether Stratum's
    autopilot can safely run automation for a given account/campaign.
    
    Score Components (Weighted):
    - EMQ Score: 25%
    - Data Freshness: 25%
    - Variance Stability: 25%
    - Anomaly Detection: 25%
    """
    platform: Platform
    account_id: str
    
    # Overall score (0-100)
    score: float = Field(ge=0, le=100)
    
    # Component scores (0-100 each)
    emq_score: float = Field(ge=0, le=100)
    freshness_score: float = Field(ge=0, le=100)
    variance_score: float = Field(ge=0, le=100)
    anomaly_score: float = Field(ge=0, le=100)
    
    # Trust gate decision
    is_healthy: bool = False                 # score >= 70
    is_degraded: bool = False                # 40 <= score < 70
    is_critical: bool = False                # score < 40
    
    # Automation permissions
    autopilot_allowed: bool = False
    manual_review_required: bool = False
    
    # Diagnostic info
    issues: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    
    last_calculated: datetime = Field(default_factory=datetime.utcnow)
    
    def evaluate_gates(self) -> None:
        """
        Set boolean flags based on score thresholds.
        
        This implements Stratum's trust-gated logic:
        - HEALTHY (≥70): Autopilot runs freely
        - DEGRADED (40-69): Autopilot paused, alerts sent
        - CRITICAL (<40): All changes blocked, immediate review
        """
        self.is_healthy = self.score >= 70
        self.is_degraded = 40 <= self.score < 70
        self.is_critical = self.score < 40
        
        self.autopilot_allowed = self.is_healthy
        self.manual_review_required = not self.is_healthy


# ============================================================================
# CAMPAIGN HIERARCHY: Account → Campaign → AdSet → Ad
# ============================================================================

class UnifiedAccount(BaseModel):
    """
    Top-level advertising account representation.
    
    An account contains multiple campaigns and has aggregate
    performance/budget settings.
    """
    # Identifiers
    platform: Platform
    account_id: str                          # Platform's native ID
    account_name: str
    
    # Business info
    business_id: Optional[str] = None        # Parent business/manager ID
    timezone: str = "UTC"
    currency: str = "USD"
    
    # Account-level settings
    daily_spend_limit: Optional[float] = None
    lifetime_spend_limit: Optional[float] = None
    
    # Health metrics
    signal_health: Optional[SignalHealth] = None
    emq_scores: List[EMQScore] = Field(default_factory=list)
    
    # Metadata
    last_synced: Optional[datetime] = None
    raw_data: Optional[Dict[str, Any]] = None  # Original API response


class UnifiedCampaign(BaseModel):
    """
    Campaign-level entity with budget and objective settings.
    
    A campaign groups ad sets/ad groups under a single objective
    and budget strategy.
    """
    # Identifiers
    platform: Platform
    account_id: str
    campaign_id: str
    campaign_name: str
    
    # Status and objective
    status: EntityStatus = EntityStatus.ACTIVE
    objective: OptimizationGoal = OptimizationGoal.PURCHASES
    
    # Budget settings
    daily_budget: Optional[float] = None
    lifetime_budget: Optional[float] = None
    budget_remaining: Optional[float] = None
    
    # Bidding
    bidding_strategy: BiddingStrategy = BiddingStrategy.LOWEST_COST
    bid_amount: Optional[float] = None       # For manual/cap strategies
    target_cpa: Optional[float] = None       # For target CPA
    target_roas: Optional[float] = None      # For target ROAS
    
    # Performance
    metrics: Optional[PerformanceMetrics] = None
    
    # Automation control
    autopilot_enabled: bool = False          # Stratum managing this campaign
    automation_rules: List[str] = Field(default_factory=list)
    
    # Timestamps
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_synced: Optional[datetime] = None
    
    # Raw platform data for debugging
    raw_data: Optional[Dict[str, Any]] = None


class UnifiedAdSet(BaseModel):
    """
    Ad Set / Ad Group level entity.
    
    This is where targeting, placements, and scheduling are defined.
    Platform terminology varies (Meta: Ad Set, Google: Ad Group, etc.)
    """
    # Identifiers
    platform: Platform
    account_id: str
    campaign_id: str
    adset_id: str
    adset_name: str
    
    # Status
    status: EntityStatus = EntityStatus.ACTIVE
    
    # Budget (if ad set level budgeting)
    daily_budget: Optional[float] = None
    lifetime_budget: Optional[float] = None
    
    # Bidding (can override campaign level)
    bid_amount: Optional[float] = None
    
    # Targeting summary (detailed targeting is platform-specific)
    targeting_summary: Optional[str] = None
    audience_size: Optional[int] = None      # Estimated reach
    
    # Scheduling
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    # Performance
    metrics: Optional[PerformanceMetrics] = None
    
    # Timestamps
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_synced: Optional[datetime] = None
    
    raw_data: Optional[Dict[str, Any]] = None


class UnifiedAd(BaseModel):
    """
    Individual ad creative with performance tracking.
    
    Contains references to creative assets and tracks
    per-ad performance metrics.
    """
    # Identifiers
    platform: Platform
    account_id: str
    campaign_id: str
    adset_id: str
    ad_id: str
    ad_name: str
    
    # Status
    status: EntityStatus = EntityStatus.ACTIVE
    
    # Creative references
    creative_id: Optional[str] = None
    headline: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    video_url: Optional[str] = None
    call_to_action: Optional[str] = None
    destination_url: Optional[str] = None
    
    # Performance
    metrics: Optional[PerformanceMetrics] = None
    
    # Review status
    review_status: Optional[str] = None      # Platform's review status
    rejection_reason: Optional[str] = None
    
    # Timestamps
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    last_synced: Optional[datetime] = None
    
    raw_data: Optional[Dict[str, Any]] = None


# ============================================================================
# AUTOMATION ACTIONS: Commands to push back to platforms
# ============================================================================

class AutomationAction(BaseModel):
    """
    Represents a change to be pushed to an advertising platform.
    
    Actions are generated by Stratum's autopilot engine and
    queued for execution after passing the trust gate.
    """
    # Tracking
    action_id: str = Field(default_factory=lambda: str(datetime.utcnow().timestamp()))
    
    # Target
    platform: Platform
    account_id: str
    entity_type: str                         # "campaign", "adset", "ad"
    entity_id: str
    
    # Action details
    action_type: str                         # "update_budget", "pause", "update_bid", etc.
    parameters: Dict[str, Any]               # Action-specific parameters
    
    # Trust gate
    signal_health_at_creation: float         # Signal health when action was generated
    requires_approval: bool = False          # If signal health was degraded
    approved_by: Optional[str] = None        # For manual approvals
    
    # Execution status
    status: str = "pending"                  # pending, approved, executing, completed, failed
    executed_at: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    
    # Audit trail
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


# ============================================================================
# WEBHOOK EVENTS: Real-time updates from platforms
# ============================================================================

class WebhookEvent(BaseModel):
    """
    Normalized webhook event from any platform.
    
    Used for real-time notifications about campaign changes,
    budget alerts, and delivery issues.
    """
    platform: Platform
    event_type: str                          # Platform-specific event type
    event_id: Optional[str] = None
    
    # Affected entity
    account_id: Optional[str] = None
    campaign_id: Optional[str] = None
    adset_id: Optional[str] = None
    ad_id: Optional[str] = None
    
    # Event data
    payload: Dict[str, Any]
    
    # Processing
    received_at: datetime = Field(default_factory=datetime.utcnow)
    processed: bool = False
    processing_result: Optional[str] = None
