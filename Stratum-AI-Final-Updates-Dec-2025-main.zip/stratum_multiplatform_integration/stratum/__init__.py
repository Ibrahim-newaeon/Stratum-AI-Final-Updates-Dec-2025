"""
Stratum AI: Multi-Platform Integration Framework
================================================

A bi-directional, real-time integration framework for managing advertising
campaigns across Meta, Google Ads, TikTok, and Snapchat.

Built on the principle of "Trust-Gated Autopilot" - automation that only
runs when data quality is verified.

Quick Start:
    
    from stratum import create_adapter, Platform
    
    # Create an adapter
    adapter = await create_adapter(Platform.META, credentials)
    
    # Pull data
    campaigns = await adapter.get_campaigns(account_id)
    
    # Push changes (through trust gate)
    from stratum.core import TrustGatedAutopilot
    
    autopilot = TrustGatedAutopilot()
    can_proceed, result = await autopilot.can_execute(action, emq_scores, metrics)
    
    if can_proceed:
        await adapter.execute_action(action)
"""

from stratum.models import (
    Platform,
    EntityStatus,
    BiddingStrategy,
    OptimizationGoal,
    UnifiedAccount,
    UnifiedCampaign,
    UnifiedAdSet,
    UnifiedAd,
    PerformanceMetrics,
    EMQScore,
    SignalHealth,
    AutomationAction,
)

from stratum.adapters.base import BaseAdapter
from stratum.adapters.meta_adapter import MetaAdapter
from stratum.adapters.google_adapter import GoogleAdsAdapter
from stratum.adapters.tiktok_adapter import TikTokAdapter
from stratum.adapters.snapchat_adapter import SnapchatAdapter

from stratum.core.signal_health import SignalHealthCalculator
from stratum.core.trust_gate import TrustGate, TrustGatedAutopilot


async def create_adapter(platform: Platform, credentials: dict) -> BaseAdapter:
    """
    Factory function to create and initialize a platform adapter.
    
    Args:
        platform: Which platform to create adapter for
        credentials: Platform-specific credentials dictionary
    
    Returns:
        Initialized adapter ready for use
    
    Example:
        adapter = await create_adapter(Platform.META, {
            "app_id": "...",
            "app_secret": "...",
            "access_token": "..."
        })
    """
    adapter_classes = {
        Platform.META: MetaAdapter,
        Platform.GOOGLE: GoogleAdsAdapter,
        Platform.TIKTOK: TikTokAdapter,
        Platform.SNAPCHAT: SnapchatAdapter,
    }
    
    adapter_class = adapter_classes.get(platform)
    if not adapter_class:
        raise ValueError(f"Unknown platform: {platform}")
    
    adapter = adapter_class(credentials)
    await adapter.initialize()
    return adapter


__all__ = [
    # Models
    "Platform",
    "EntityStatus",
    "BiddingStrategy",
    "OptimizationGoal",
    "UnifiedAccount",
    "UnifiedCampaign",
    "UnifiedAdSet",
    "UnifiedAd",
    "PerformanceMetrics",
    "EMQScore",
    "SignalHealth",
    "AutomationAction",
    
    # Adapters
    "BaseAdapter",
    "MetaAdapter",
    "GoogleAdsAdapter",
    "TikTokAdapter",
    "SnapchatAdapter",
    
    # Core
    "SignalHealthCalculator",
    "TrustGate",
    "TrustGatedAutopilot",
    
    # Factory
    "create_adapter",
]
