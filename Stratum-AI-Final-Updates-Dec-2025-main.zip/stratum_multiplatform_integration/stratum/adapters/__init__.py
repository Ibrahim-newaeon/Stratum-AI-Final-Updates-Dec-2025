"""
Stratum AI: Platform Adapters
=============================

Each adapter translates between Stratum's unified models and a platform's
native API format. All adapters implement the BaseAdapter interface.
"""

from stratum.adapters.base import (
    BaseAdapter,
    AdapterError,
    AuthenticationError,
    RateLimitError,
    PlatformError,
    ValidationError,
)
from stratum.adapters.meta_adapter import MetaAdapter
from stratum.adapters.google_adapter import GoogleAdsAdapter
from stratum.adapters.tiktok_adapter import TikTokAdapter
from stratum.adapters.snapchat_adapter import SnapchatAdapter

__all__ = [
    "BaseAdapter",
    "AdapterError",
    "AuthenticationError",
    "RateLimitError",
    "PlatformError",
    "ValidationError",
    "MetaAdapter",
    "GoogleAdsAdapter",
    "TikTokAdapter",
    "SnapchatAdapter",
]
