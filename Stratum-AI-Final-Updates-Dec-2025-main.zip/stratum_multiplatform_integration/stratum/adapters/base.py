"""
Stratum AI: Base Adapter Interface
==================================

This module defines the abstract interface that all platform adapters must implement.
By defining a consistent interface, Stratum's core automation logic can work with
any advertising platform without knowing the specific API details.

The adapter pattern here is crucial for several reasons. First, it allows us to
add new platforms (like Pinterest, LinkedIn, or Twitter) without modifying any
core Stratum logic. Second, it enables testing with mock adapters that don't
make real API calls. Third, it provides a clean separation between business
logic (trust gates, autopilot rules) and platform-specific implementation details.

Each concrete adapter (MetaAdapter, GoogleAdapter, etc.) translates between
Stratum's unified data models and the platform's native API formats. The
translation happens in both directions: when pulling data, raw API responses
are converted to UnifiedCampaign objects; when pushing changes, AutomationAction
objects are converted to platform-specific API calls.
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional, Dict, Any, AsyncIterator
import asyncio
import logging

from stratum.models import (
    Platform,
    UnifiedAccount,
    UnifiedCampaign,
    UnifiedAdSet,
    UnifiedAd,
    PerformanceMetrics,
    EMQScore,
    SignalHealth,
    AutomationAction,
    WebhookEvent,
    EntityStatus
)


# Configure logging for all adapters
logger = logging.getLogger("stratum.adapters")


class RateLimiter:
    """
    Token bucket rate limiter for API calls.
    
    Each platform has different rate limits, and we need to respect them
    to avoid getting blocked or having our access revoked. This class
    implements a simple token bucket algorithm where tokens are added
    at a fixed rate, and each API call consumes one token.
    
    Platform Rate Limits (approximate):
    - Meta: Calculated dynamically based on account tier (typically 4800/hour)
    - Google: 10,000 operations per day per developer token
    - TikTok: 1000 requests per minute
    - Snapchat: 1000 requests per 5 minutes
    """
    
    def __init__(
        self,
        calls_per_minute: int = 60,
        burst_size: int = 10
    ):
        """
        Initialize the rate limiter with the given constraints.
        
        Args:
            calls_per_minute: Maximum sustained rate of API calls
            burst_size: Maximum number of calls that can be made instantly
        """
        self.calls_per_minute = calls_per_minute
        self.burst_size = burst_size
        self.tokens = burst_size
        self.last_update = datetime.utcnow()
        self._lock = asyncio.Lock()
    
    async def acquire(self) -> None:
        """
        Wait until a rate limit token is available, then consume it.
        
        This method should be called before every API request. It will
        block if we've exhausted our rate limit budget, automatically
        waiting until tokens regenerate.
        """
        async with self._lock:
            now = datetime.utcnow()
            time_passed = (now - self.last_update).total_seconds()
            
            # Regenerate tokens based on time passed
            self.tokens = min(
                self.burst_size,
                self.tokens + (time_passed * self.calls_per_minute / 60)
            )
            self.last_update = now
            
            # Wait if no tokens available
            if self.tokens < 1:
                wait_time = (1 - self.tokens) * 60 / self.calls_per_minute
                logger.warning(f"Rate limit reached, waiting {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
                self.tokens = 1
            
            self.tokens -= 1


class BaseAdapter(ABC):
    """
    Abstract base class for all advertising platform adapters.
    
    Each platform adapter must implement these methods to enable
    bi-directional integration. The interface is designed around
    the common operations needed by Stratum's autopilot engine.
    
    Key Design Principles:
    
    1. Async by default: All methods are async to support concurrent
       operations across multiple accounts and platforms.
    
    2. Unified models: All methods return Stratum's unified models,
       never raw platform data (except in raw_data fields for debugging).
    
    3. Error handling: Methods should raise specific exceptions rather
       than returning None for errors, enabling proper error recovery.
    
    4. Rate limiting: Built-in rate limiting prevents API quota exhaustion.
    
    Usage Pattern:
    
        adapter = MetaAdapter(credentials)
        await adapter.initialize()
        
        # Pull data (read direction)
        campaigns = await adapter.get_campaigns(account_id)
        metrics = await adapter.get_metrics(account_id, date_range)
        emq = await adapter.get_emq_scores(account_id)
        
        # Push changes (write direction)
        action = AutomationAction(action_type="update_budget", ...)
        result = await adapter.execute_action(action)
        
        await adapter.cleanup()
    """
    
    def __init__(self, credentials: Dict[str, str]):
        """
        Initialize the adapter with platform credentials.
        
        Args:
            credentials: Platform-specific authentication credentials.
                         See each adapter's docstring for required keys.
        """
        self.credentials = credentials
        self.rate_limiter = RateLimiter()
        self._initialized = False
    
    @property
    @abstractmethod
    def platform(self) -> Platform:
        """Return the platform identifier for this adapter."""
        pass
    
    # ========================================================================
    # LIFECYCLE METHODS
    # ========================================================================
    
    @abstractmethod
    async def initialize(self) -> None:
        """
        Initialize the adapter and validate credentials.
        
        This method should:
        1. Validate that all required credentials are present
        2. Initialize the platform SDK/client
        3. Make a test API call to verify authentication
        4. Set up any persistent connections or sessions
        
        Raises:
            ValueError: If credentials are missing or invalid
            ConnectionError: If the platform API is unreachable
            AuthenticationError: If credentials are rejected
        """
        pass
    
    @abstractmethod
    async def cleanup(self) -> None:
        """
        Clean up adapter resources.
        
        Called when shutting down or when switching accounts.
        Should close any open connections and release resources.
        """
        pass
    
    async def health_check(self) -> bool:
        """
        Verify the adapter can communicate with the platform API.
        
        Returns:
            True if the connection is healthy, False otherwise.
        """
        try:
            # Default implementation: try to get accounts
            accounts = await self.get_accounts()
            return len(accounts) > 0
        except Exception as e:
            logger.error(f"{self.platform.value} health check failed: {e}")
            return False
    
    # ========================================================================
    # READ OPERATIONS (PULL DATA)
    # ========================================================================
    
    @abstractmethod
    async def get_accounts(self) -> List[UnifiedAccount]:
        """
        Get all advertising accounts accessible with current credentials.
        
        Returns:
            List of UnifiedAccount objects representing accessible accounts.
        """
        pass
    
    @abstractmethod
    async def get_campaigns(
        self,
        account_id: str,
        status_filter: Optional[List[EntityStatus]] = None
    ) -> List[UnifiedCampaign]:
        """
        Get campaigns for an account, optionally filtered by status.
        
        Args:
            account_id: Platform-specific account identifier
            status_filter: If provided, only return campaigns with these statuses
        
        Returns:
            List of UnifiedCampaign objects
        """
        pass
    
    @abstractmethod
    async def get_adsets(
        self,
        account_id: str,
        campaign_id: Optional[str] = None
    ) -> List[UnifiedAdSet]:
        """
        Get ad sets for an account, optionally filtered to a specific campaign.
        
        Args:
            account_id: Platform-specific account identifier
            campaign_id: If provided, only return ad sets in this campaign
        
        Returns:
            List of UnifiedAdSet objects
        """
        pass
    
    @abstractmethod
    async def get_ads(
        self,
        account_id: str,
        adset_id: Optional[str] = None
    ) -> List[UnifiedAd]:
        """
        Get ads for an account, optionally filtered to a specific ad set.
        
        Args:
            account_id: Platform-specific account identifier
            adset_id: If provided, only return ads in this ad set
        
        Returns:
            List of UnifiedAd objects
        """
        pass
    
    @abstractmethod
    async def get_metrics(
        self,
        account_id: str,
        entity_type: str,
        entity_ids: List[str],
        date_start: datetime,
        date_end: datetime,
        breakdown: Optional[str] = None
    ) -> Dict[str, PerformanceMetrics]:
        """
        Get performance metrics for specified entities over a date range.
        
        This is the primary method for pulling performance data that feeds
        into signal health calculations and reporting.
        
        Args:
            account_id: Platform-specific account identifier
            entity_type: "campaign", "adset", or "ad"
            entity_ids: List of entity IDs to fetch metrics for
            date_start: Start of date range (inclusive)
            date_end: End of date range (inclusive)
            breakdown: Optional breakdown dimension (e.g., "day", "age", "gender")
        
        Returns:
            Dictionary mapping entity_id to PerformanceMetrics
        """
        pass
    
    @abstractmethod
    async def get_emq_scores(
        self,
        account_id: str
    ) -> List[EMQScore]:
        """
        Get Event Match Quality scores for the account.
        
        EMQ is a critical component of signal health. This method fetches
        the current EMQ scores for all conversion events being tracked.
        
        Args:
            account_id: Platform-specific account identifier
        
        Returns:
            List of EMQScore objects, one per conversion event
        """
        pass
    
    # ========================================================================
    # WRITE OPERATIONS (PUSH CHANGES)
    # ========================================================================
    
    @abstractmethod
    async def execute_action(
        self,
        action: AutomationAction
    ) -> AutomationAction:
        """
        Execute an automation action on the platform.
        
        This is the primary method for pushing changes. The action object
        contains all the information needed to make the change, and this
        method updates the action with the execution result.
        
        Args:
            action: AutomationAction with action_type and parameters
        
        Returns:
            The same AutomationAction with updated status, result, and any errors
        
        Supported action_type values:
        - update_budget: Change daily or lifetime budget
        - update_bid: Change bid amount or strategy
        - update_status: Pause, enable, or archive entity
        - update_targeting: Modify audience targeting
        - create_campaign: Create new campaign
        - create_adset: Create new ad set
        - create_ad: Create new ad
        - duplicate_campaign: Copy existing campaign
        """
        pass
    
    async def execute_actions_batch(
        self,
        actions: List[AutomationAction]
    ) -> List[AutomationAction]:
        """
        Execute multiple actions efficiently.
        
        Some platforms support batch operations that are more efficient
        than individual calls. This default implementation falls back
        to sequential execution but can be overridden.
        
        Args:
            actions: List of AutomationAction objects
        
        Returns:
            List of AutomationAction objects with updated statuses
        """
        results = []
        for action in actions:
            result = await self.execute_action(action)
            results.append(result)
        return results
    
    # ========================================================================
    # CREATIVE OPERATIONS
    # ========================================================================
    
    @abstractmethod
    async def upload_image(
        self,
        account_id: str,
        image_data: bytes,
        filename: str
    ) -> str:
        """
        Upload an image creative and return the platform's image ID.
        
        This enables AI-generated creatives to be pushed to the platform.
        
        Args:
            account_id: Platform-specific account identifier
            image_data: Raw image bytes (PNG, JPG, etc.)
            filename: Original filename with extension
        
        Returns:
            Platform-specific image/creative ID for use in ads
        """
        pass
    
    @abstractmethod
    async def upload_video(
        self,
        account_id: str,
        video_data: bytes,
        filename: str
    ) -> str:
        """
        Upload a video creative and return the platform's video ID.
        
        Args:
            account_id: Platform-specific account identifier
            video_data: Raw video bytes
            filename: Original filename with extension
        
        Returns:
            Platform-specific video/creative ID for use in ads
        """
        pass
    
    # ========================================================================
    # REAL-TIME / WEBHOOK OPERATIONS
    # ========================================================================
    
    async def setup_webhooks(
        self,
        callback_url: str,
        event_types: List[str]
    ) -> bool:
        """
        Register webhook subscriptions for real-time updates.
        
        Not all platforms support webhooks. This default implementation
        returns False, indicating webhooks are not available.
        
        Args:
            callback_url: URL to receive webhook POST requests
            event_types: Platform-specific event types to subscribe to
        
        Returns:
            True if webhooks were successfully configured
        """
        logger.info(f"{self.platform.value} does not support webhooks")
        return False
    
    async def process_webhook(
        self,
        payload: Dict[str, Any]
    ) -> WebhookEvent:
        """
        Process an incoming webhook payload into a normalized event.
        
        Args:
            payload: Raw webhook payload from the platform
        
        Returns:
            Normalized WebhookEvent object
        """
        return WebhookEvent(
            platform=self.platform,
            event_type="unknown",
            payload=payload
        )
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def _map_status_to_platform(self, status: EntityStatus) -> str:
        """
        Convert unified status to platform-specific status string.
        
        Override in concrete adapters to provide correct mapping.
        """
        raise NotImplementedError("Subclass must implement status mapping")
    
    def _map_status_from_platform(self, platform_status: str) -> EntityStatus:
        """
        Convert platform-specific status to unified status.
        
        Override in concrete adapters to provide correct mapping.
        """
        raise NotImplementedError("Subclass must implement status mapping")


class AdapterError(Exception):
    """Base exception for adapter errors."""
    pass


class AuthenticationError(AdapterError):
    """Raised when API authentication fails."""
    pass


class RateLimitError(AdapterError):
    """Raised when API rate limit is exceeded."""
    pass


class ValidationError(AdapterError):
    """Raised when input validation fails."""
    pass


class PlatformError(AdapterError):
    """Raised when the platform returns an error."""
    
    def __init__(self, message: str, platform_code: Optional[str] = None):
        super().__init__(message)
        self.platform_code = platform_code
