# Stratum AI: Multi-Platform Bi-Directional Integration Framework

## Overview

This framework provides **bi-directional, real-time integration** between Stratum AI's trust-gated automation system and all four major advertising platforms:

| Platform | SDK/Library | Auth Method | Real-Time Capability |
|----------|-------------|-------------|---------------------|
| **Meta** | `facebook-business` | System User Token | Webhooks + Polling |
| **Google Ads** | `google-ads` | OAuth 2.0 / Service Account | Change History API |
| **TikTok** | `TikTok-Business-API` | OAuth 2.0 | Polling (15-min) |
| **Snapchat** | Custom REST | OAuth 2.0 | Polling (hourly) |

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        STRATUM AI CORE                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────┐ │
│  │  Signal Health  │  │   Trust Gate    │  │  Autopilot Engine   │ │
│  │   Calculator    │◄─┤   Evaluator     │◄─┤   (Automation)      │ │
│  └────────┬────────┘  └────────┬────────┘  └──────────┬──────────┘ │
│           │                    │                       │            │
│           ▼                    ▼                       ▼            │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │              UNIFIED PLATFORM ADAPTER LAYER                   │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
            │                    │                       │
            ▼                    ▼                       ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│     META      │  │  GOOGLE ADS   │  │    TIKTOK     │  │   SNAPCHAT    │
│   Marketing   │  │     API       │  │  Business API │  │  Marketing    │
│     API       │  │               │  │               │  │     API       │
└───────────────┘  └───────────────┘  └───────────────┘  └───────────────┘
       │                  │                  │                  │
       ▼                  ▼                  ▼                  ▼
   PULL DATA          PULL DATA          PULL DATA          PULL DATA
   PUSH CHANGES       PUSH CHANGES       PUSH CHANGES       PUSH CHANGES
```

## Quick Start

```bash
# Install dependencies
pip install facebook-business google-ads TikTok-Business-API requests pydantic --break-system-packages

# Copy configuration template
cp config.example.yaml config.yaml

# Edit with your credentials
nano config.yaml

# Run integration test
python -m stratum.test_connections
```

## Directory Structure

```
stratum_multiplatform_integration/
├── config.yaml                    # Platform credentials
├── stratum/
│   ├── __init__.py
│   ├── models.py                  # Unified data models
│   ├── adapters/
│   │   ├── __init__.py
│   │   ├── base.py               # Abstract adapter interface
│   │   ├── meta_adapter.py       # Meta Marketing API
│   │   ├── google_adapter.py     # Google Ads API
│   │   ├── tiktok_adapter.py     # TikTok Business API
│   │   └── snapchat_adapter.py   # Snapchat Marketing API
│   ├── core/
│   │   ├── signal_health.py      # Signal health calculation
│   │   ├── trust_gate.py         # Trust gate evaluation
│   │   └── autopilot.py          # Automation engine
│   └── workers/
│       ├── data_sync.py          # Real-time sync worker
│       └── automation_runner.py  # Budget/bid automation
└── tests/
    └── test_connections.py
```

## Signal Health Integration

The framework integrates with Stratum's trust-gated autopilot by:

1. **PULL**: Collecting EMQ, conversion data, and performance metrics
2. **CALCULATE**: Computing signal health score (0-100)
3. **GATE**: Only allowing automation when signal health ≥ 70
4. **PUSH**: Executing budget/bid/creative changes when approved

## Author

Built for Stratum AI Platform — The Trust-Gated Autopilot for Revenue Operations
